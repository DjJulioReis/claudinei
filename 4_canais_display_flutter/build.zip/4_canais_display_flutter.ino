#include <Arduino.h>
#include <Wire.h>
#include <Preferences.h> 
#include "BluetoothSerial.h"
#include "SSD1306Ascii.h"
#include "SSD1306AsciiWire.h"

// --- INCLUSÃO DA LOGO CUSTOMIZADA ---
#include "MILETO_LOGO_1.h" 

#if !defined(CONFIG_BT_ENABLED) || !defined(CONFIG_BLUEDROID_ENABLED)
#error O Bluetooth nao esta ativado!
#endif

SSD1306AsciiWire oled;
Preferences preferences;
BluetoothSerial SerialBT;

// --- MAPEAMENTO DE PINOS ---
#define MOSFET_CH1 12  
#define MOSFET_CH2 13  
#define MOSFET_CH3 14  
#define MOSFET_CH4 27  

// Painel de Controle Físico
#define BTN_MUDAR_CAMPO  25 // Botão 1: Seleciona Efeitos / Campos do Menu (Move a seta '>')
#define BTN_FRENTE       33 // Botão 2: Sobe / Mais (+)
#define BTN_VOLTA        32 // Botão 3: Desce / Menos (-)
#define BTN_GRAVAR       26 // Botão 4: Grava as configurações na Flash
#define CHAVE_DMX_MANUAL  4 // Chave Seletora: Manual / Mesa DMX

#define PWM_FREQ 4000  
#define PWM_RES  8     

// --- VARIÁVEIS DE CONTROLE ---
bool sistemaEmModoDMX = false; 
int modoAtual = 0; 
int velocidad = 100;    
int brilhoGeral = 255;   
int enderecoDMX = 1;    

// Controle do Menu de Setas
int linhaSelecionada = 0; // 0 = Efeito, 1 = Canal/Velocidade, 2 = Dimmer
int canalSelecionado = 0; // 0=CH1, 1=CH2, 2=CH3, 3=CH4
int brilhoCanais[4] = {255, 255, 255, 255}; // Dimmer individual de cada canal

const char* nomesEfeitos[] = {"MANUAL", "FADE", "STROBO", "SEQUENC", "FIXO"};

unsigned long tempoUltimaAtividade = 0; 
bool telaAcesa = true;
#define TEMPO_SLEEP_TELA 125000 

unsigned long ultimaAtualizacaoEfeito = 0;
int fadeValue = 0;
bool fadeDirection = true;
bool estadoStrobo = false;
int passoAlternado = 0;
unsigned long ultimoDebounce = 0; 

unsigned long ultimoPiscaStatus = 0;
bool estadoLedStatus = false;
bool dispositivoConectado = false;

// --- DECLARAÇÃO DE FUNÇÕES ---
void atualizarDisplay();
void acordaTela();
void executarEfeitos(); 
void imprimeNumero(int num);
void salvarConfiguracao();
void receberDadosBluetooth();
void processarComandoApp(String pacote);
void desenharLogo(const uint8_t* bitmap);

void setup() {
  Serial.begin(115200);
  delay(500); 
  Serial.println("\n====================================");
  Serial.println("   MILETO - FIRMWARE ESTRUTURADO V5  ");
  Serial.println("====================================");

  pinMode(MOSFET_CH2, OUTPUT);

  // Inicializa os Pinos de Controle
  pinMode(BTN_MUDAR_CAMPO, INPUT_PULLUP);
  pinMode(BTN_FRENTE, INPUT_PULLUP);
  pinMode(BTN_VOLTA, INPUT_PULLUP);
  pinMode(BTN_GRAVAR, INPUT_PULLUP); 
  pinMode(CHAVE_DMX_MANUAL, INPUT_PULLUP);

  // Ativa PWM nos canais para testes offline
  ledcAttach(MOSFET_CH1, PWM_FREQ, PWM_RES);
  ledcAttach(MOSFET_CH3, PWM_FREQ, PWM_RES);
  ledcAttach(MOSFET_CH4, PWM_FREQ, PWM_RES);

  // Inicializa Barramento I2C e OLED
  Wire.begin(21, 22); 
  Wire.setClock(400000L); 

  oled.begin(&Adafruit128x64, 0x3C);
  oled.setFont(Adafruit5x7); 

  // --- EXIBE A LOGO DE ABERTURA (SPLASH SCREEN) ---
  desenharLogo(MILETO_LOGO_1);
  delay(3000); // <--- MUDADO PARA 3 SEGUNDOS DE EXIBIÇÃO

  // Carrega configurações da Flash NVS
  preferences.begin("mileto_cfg", false);
  enderecoDMX = preferences.getInt("dmx", 1);
  modoAtual = preferences.getInt("modo", 0);
  velocidad = preferences.getInt("vel", 100);
  brilhoGeral = preferences.getInt("dim", 255);
  brilhoCanais[0] = preferences.getInt("ch1", 255);
  brilhoCanais[1] = preferences.getInt("ch2", 255);
  brilhoCanais[2] = preferences.getInt("ch3", 255);
  brilhoCanais[3] = preferences.getInt("ch4", 255);

  SerialBT.begin("MILETO");
  tempoUltimaAtividade = millis(); 
  
  // Limpa a logo e monta a interface principal do menu
  atualizarDisplay();
}

void loop() {
  // --- CONTROLE DE STATUS DO LED DE CONEXÃO (CH2) ---
  if (!dispositivoConectado) {
    if (millis() - ultimoPiscaStatus >= 200) {
      ultimoPiscaStatus = millis();
      estadoLedStatus = !estadoLedStatus;
      digitalWrite(MOSFET_CH2, estadoLedStatus ? HIGH : LOW);
    }
  } else {
    if (!estadoLedStatus) {
      estadoLedStatus = true;
      digitalWrite(MOSFET_CH2, HIGH);
      ledcAttach(MOSFET_CH1, PWM_FREQ, PWM_RES);
      ledcAttach(MOSFET_CH2, PWM_FREQ, PWM_RES);
      ledcAttach(MOSFET_CH3, PWM_FREQ, PWM_RES);
      ledcAttach(MOSFET_CH4, PWM_FREQ, PWM_RES);
    }
  }

  // --- LEITURA DA CHAVE DMX / MANUAL ---
  bool estadoChaveDMX = (digitalRead(CHAVE_DMX_MANUAL) == LOW); 
  if (estadoChaveDMX != sistemaEmModoDMX) {
    sistemaEmModoDMX = estadoChaveDMX;
    acordaTela();
    if (dispositivoConectado) {
      SerialBT.print("CHAVE_MODO:");
      SerialBT.println(sistemaEmModoDMX ? "DMX" : "RF");
    }
    atualizarDisplay();
  }

  // --- CONTROLE DOS BOTÕES DO MENU (MODO MANUAL) ---
  if (!sistemaEmModoDMX) {

    // BOTÃO 1: MUDAR CAMPO (SETA DO MENU)
    if (digitalRead(BTN_MUDAR_CAMPO) == LOW) {
      delay(50);
      if (digitalRead(BTN_MUDAR_CAMPO) == LOW) {
        if (millis() - ultimoDebounce >= 250) {
          ultimoDebounce = millis();
          acordaTela();
          
          linhaSelecionada++;
          if (linhaSelecionada > 2) linhaSelecionada = 0; 
          
          atualizarDisplay();
          while(digitalRead(BTN_MUDAR_CAMPO) == LOW) { delay(10); }
        }
      }
    }

    // BOTÃO 2: SOBE / INCREMENTAR (+)
    if (digitalRead(BTN_FRENTE) == LOW) {
      delay(50);
      if (digitalRead(BTN_FRENTE) == LOW) {
        if (millis() - ultimoDebounce >= 150) {
          ultimoDebounce = millis();
          acordaTela();
          
          if (linhaSelecionada == 0) { 
            modoAtual = (modoAtual + 1) % 5;
          } 
          else if (linhaSelecionada == 1) { 
            if (modoAtual == 0) {
              canalSelecionado = (canalSelecionado + 1) % 4;
            } else {
              velocidad += 5; if (velocidad > 100) velocidad = 100;
            }
          } 
          else if (linhaSelecionada == 2) { 
            if (modoAtual == 0) {
              brilhoCanais[canalSelecionado] = min(brilhoCanais[canalSelecionado] + 15, 255);
            } else {
              brilhoGeral = min(brilhoGeral + 15, 255);
            }
          }
          
          atualizarDisplay();
          while(digitalRead(BTN_FRENTE) == LOW) { delay(10); }
        }
      }
    }

    // BOTÃO 3: DESCE / DECREMENTAR (-)
    if (digitalRead(BTN_VOLTA) == LOW) {
      delay(50);
      if (digitalRead(BTN_VOLTA) == LOW) {
        if (millis() - ultimoDebounce >= 150) {
          ultimoDebounce = millis();
          acordaTela();
          
          if (linhaSelecionada == 0) {
            modoAtual--; if (modoAtual < 0) modoAtual = 4;
          } 
          else if (linhaSelecionada == 1) {
            if (modoAtual == 0) {
              canalSelecionado--; if (canalSelecionado < 0) canalSelecionado = 3;
            } else {
              velocidad -= 5; if (velocidad < 0) velocidad = 0;
            }
          } 
          else if (linhaSelecionada == 2) {
            if (modoAtual == 0) {
              brilhoCanais[canalSelecionado] = max(brilhoCanais[canalSelecionado] - 15, 0);
            } else {
              brilhoGeral = max(brilhoGeral - 15, 0);
            }
          }
          
          atualizarDisplay();
          while(digitalRead(BTN_VOLTA) == LOW) { delay(10); }
        }
      }
    }

    // BOTÃO 4: GRAVAR CONFIGURAÇÃO
    if (digitalRead(BTN_GRAVAR) == LOW) {
      delay(50);
      if (digitalRead(BTN_GRAVAR) == LOW) {
        if (millis() - ultimoDebounce >= 400) {
          ultimoDebounce = millis();
          acordaTela();
          
          oled.clear();
          oled.write("\n\n   GRAVANDO...\n");
          oled.write("   MEMORIA FLASH OK");
          
          salvarConfiguracao();
          delay(800); 
          atualizarDisplay();
          while(digitalRead(BTN_GRAVAR) == LOW) { delay(10); }
        }
      }
    }
  }

  // --- ECONOMIA DE TELA ---
  if (telaAcesa && (millis() - tempoUltimaAtividade >= TEMPO_SLEEP_TELA)) {
    oled.clear(); 
    oled.ssd1306WriteCmd(SSD1306_DISPLAYOFF); 
    telaAcesa = false;
  }

  receberDadosBluetooth();

  if (!sistemaEmModoDMX) {
    executarEfeitos(); 
  }
}

// --- FUNÇÃO CORRIGIDA PARA INJETAR O BITMAP DA LOGO DIRETO NA RAM ---
void desenharLogo(const uint8_t* bitmap) {
  oled.clear();
  // Varia pelas 8 páginas verticais do display
  for (uint8_t pagina = 0; pagina < 8; pagina++) {
    oled.setCursor(0, pagina); // Posiciona o cursor no início da página atual
    for (uint8_t coluna = 0; coluna < 128; coluna++) {
      // Envia os bytes do array sequencialmente para preencher as colunas
      oled.ssd1306WriteRam(pgm_read_byte(&bitmap[pagina * 128 + coluna]));
    }
  }
}

void executarEfeitos() { 
  unsigned long tempoAtual = millis();
  int delayEfeito = map(velocidad, 0, 100, 300, 5); 

  switch (modoAtual) {
    case 0: 
      ledcWrite(MOSFET_CH1, brilhoCanais[0]); 
      if (dispositivoConectado) ledcWrite(MOSFET_CH2, brilhoCanais[1]);
      ledcWrite(MOSFET_CH3, brilhoCanais[2]); 
      ledcWrite(MOSFET_CH4, brilhoCanais[3]); 
      break;
      
    case 1: // FADE
      if (tempoAtual - ultimaAtualizacaoEfeito >= (unsigned long)delayEfeito) {
        ultimaAtualizacaoEfeito = tempoAtual;
        if (fadeDirection) fadeValue += 5; else fadeValue -= 5;
        if (fadeValue >= 255 || fadeValue <= 0) fadeDirection = !fadeDirection;
        ledcWrite(MOSFET_CH1, (fadeValue * brilhoGeral) / 255);
        if (dispositivoConectado) ledcWrite(MOSFET_CH2, ((255 - fadeValue) * brilhoGeral) / 255);
        ledcWrite(MOSFET_CH3, ((255 - fadeValue) * brilhoGeral) / 255);
        ledcWrite(MOSFET_CH4, (fadeValue * brilhoGeral) / 255);
      }
      break;
      
    case 2: // STROBO
      if (tempoAtual - ultimaAtualizacaoEfeito >= (unsigned long)delayEfeito) {
        ultimaAtualizacaoEfeito = tempoAtual; estadoStrobo = !estadoStrobo;
        int intensidade = estadoStrobo ? brilhoGeral : 0; 
        ledcWrite(MOSFET_CH1, intensidade); 
        if (dispositivoConectado) ledcWrite(MOSFET_CH2, intensidade);
        ledcWrite(MOSFET_CH3, intensidade); 
        ledcWrite(MOSFET_CH4, intensidade);
      }
      break;
      
    case 3: // SEQUENCIAL
      if (tempoAtual - ultimaAtualizacaoEfeito >= (unsigned long)delayEfeito * 2) {
        ultimaAtualizacaoEfeito = tempoAtual; passoAlternado = (passoAlternado + 1) % 4;
        ledcWrite(MOSFET_CH1, (passoAlternado == 0) ? brilhoGeral : 0);
        if (dispositivoConectado) ledcWrite(MOSFET_CH2, (passoAlternado == 1) ? brilhoGeral : 0);
        ledcWrite(MOSFET_CH3, (passoAlternado == 2) ? brilhoGeral : 0);
        ledcWrite(MOSFET_CH4, (passoAlternado == 3) ? brilhoGeral : 0);
      }
      break;
      
    case 4: // FIXO
      ledcWrite(MOSFET_CH1, brilhoGeral); 
      if (dispositivoConectado) ledcWrite(MOSFET_CH2, brilhoGeral);
      ledcWrite(MOSFET_CH3, brilhoGeral); 
      ledcWrite(MOSFET_CH4, brilhoGeral);
      break;
  }
}

void receberDadosBluetooth() {
  if (SerialBT.available()) {
    acordaTela();
    if (!dispositivoConectado) {
      dispositivoConectado = true;
      SerialBT.println("CONNECTED_OK"); 
    }
    String pacoteString = SerialBT.readStringUntil('\n'); 
    pacoteString.trim();
    if(pacoteString.length() > 0) {
      processarComandoApp(pacoteString);
      atualizarDisplay();
    }
  }
  if (dispositivoConectado && !SerialBT.hasClient()) {
    dispositivoConectado = false;
    estadoLedStatus = false;
    ledcDetach(MOSFET_CH2); 
    atualizarDisplay();
  }
}

void processarComandoApp(String pacote) {
  int divisorIndex = pacote.indexOf(':');
  if (divisorIndex == -1) return;

  String comando = pacote.substring(0, divisorIndex);
  String valor = pacote.substring(divisorIndex + 1);

  if (comando == "CHAVE_MODO") { sistemaEmModoDMX = (valor == "DMX"); }
  else if (comando == "SET_MODO") { modoAtual = valor.toInt(); } 
  else if (comando == "SET_VEL")  { velocidad = valor.toInt(); } 
  else if (comando == "SET_DIM")  { brilhoGeral = map(valor.toInt(), 0, 100, 0, 255); } 
  else if (comando == "GRAVAR")   { salvarConfiguracao(); }
}

void acordaTela() {
  tempoUltimaAtividade = millis(); 
  if (!telaAcesa) { oled.ssd1306WriteCmd(SSD1306_DISPLAYON); telaAcesa = true; }
}

void salvarConfiguracao() {
  preferences.putInt("dmx", enderecoDMX);
  preferences.putInt("modo", modoAtual);
  preferences.putInt("vel", velocidad);
  preferences.putInt("dim", brilhoGeral);
  preferences.putInt("ch1", brilhoCanais[0]);
  preferences.putInt("ch2", brilhoCanais[1]);
  preferences.putInt("ch3", brilhoCanais[2]);
  preferences.putInt("ch4", brilhoCanais[3]);
}

void imprimeNumero(int num) {
  if (num == 0) { oled.write('0'); return; }
  char buf[5]; int i = 0;
  while (num > 0) { buf[i++] = (num % 10) + '0'; num /= 10; }
  while (i > 0) { oled.write(buf[--i]); }
}

void atualizarDisplay() {
  if (!telaAcesa) return; 
  oled.clear();

  if (sistemaEmModoDMX) {
    oled.write("   --- MESA DMX ---\n\n");
    oled.write(" CANAL: "); imprimeNumero(enderecoDMX);
  } 
  else {
    oled.write(dispositivoConectado ? "   --- BT APP ---\n" : "   - PAINEL RF -\n");

    // LINHA 0: Seleção Global do Modo/Efeito
    oled.write(linhaSelecionada == 0 ? "> " : "  ");
    oled.write("MODO: "); oled.write(nomesEfeitos[modoAtual]);
    oled.write("\n");

    // LINHA 1: Ajuste de Canal (Se manual) ou Velocidade (Se efeito)
    oled.write(linhaSelecionada == 1 ? "> " : "  ");
    if (modoAtual == 0) {
      oled.write("CANAL: CH"); imprimeNumero(canalSelecionado + 1);
    } else {
      oled.write("VEL: "); imprimeNumero(velocidad); oled.write("%");
    }
    oled.write("\n");

    // LINHA 2: Ajuste de Brilho do Canal Ativo ou Geral dos Efeitos
    oled.write(linhaSelecionada == 2 ? "> " : "  ");
    if (modoAtual == 0) {
      oled.write("DIM CH: ");
      imprimeNumero(map(brilhoCanais[canalSelecionado], 0, 255, 0, 100));
    } else {
      oled.write("DIM GERAL: ");
      imprimeNumero(map(brilhoGeral, 0, 255, 0, 100));
    }
    oled.write("%");
  }
}